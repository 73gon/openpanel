# @zonsh/ui

The zon component library: React 19 components on Base UI, styled in the zon
material with Tailwind CSS v4. Monochrome, three typefaces, one motion curve.

```bash
npm install @zonsh/ui
```

```css
/* app.css — Tailwind first, then the library */
@import "tailwindcss";
@import "@zonsh/ui/styles.css";
```

```tsx
import { Button, Dialog, DialogContent, DialogTrigger } from "@zonsh/ui";
```

The stylesheet points your Tailwind at the components' classes, so there is nothing to
configure. Requires React 19 and Tailwind CSS 4.1.15 or later. Dark mode: add `.dark` to
`<html>` (see `ThemeProvider` and `themeScript`).

## Fonts

The Licht typefaces are served from your own origin at `/licht/fonts/*`, never hotlinked. With
Vite, the plugin proxies them from zon.sh:

```ts
// vite.config.ts
import { zonFonts } from "@zonsh/ui/vite";
export default defineConfig({ plugins: [react(), tailwindcss(), zonFonts()] });
```

On any other host, rewrite `/licht/fonts/*` to `https://www.zon.sh/licht/fonts/*`.

## Next.js

The components are client modules, so a server component renders them as they are. Make
`app/globals.css` just the two imports above (the template's own styles and Geist fonts would
override zon's), and rewrite the fonts in `next.config.ts`:

```ts
async rewrites() {
  return [{ source: "/licht/fonts/:path*", destination: "https://www.zon.sh/licht/fonts/:path*" }];
}
```

## Optional components

Components that bring a heavy library of their own have their own entry. Add the library when
you use one; the package lists it as an optional peer dependency.

| Import                  | Add                                         |
| ----------------------- | ------------------------------------------- |
| `@zonsh/ui/calendar`    | `react-day-picker`                          |
| `@zonsh/ui/carousel`    | `embla-carousel-react`                      |
| `@zonsh/ui/chart`       | `recharts`                                  |
| `@zonsh/ui/data-table`  | `@tanstack/react-table`                     |
| `@zonsh/ui/date-picker` | `react-day-picker` `date-fns`               |
| `@zonsh/ui/filter-bar`  | `react-day-picker`                          |
| `@zonsh/ui/graph`       | `@xyflow/react` `@dagrejs/dagre` `d3-force` |
| `@zonsh/ui/pdf-viewer`  | `pdfjs-dist`                                |
| `@zonsh/ui/resizable`   | `react-resizable-panels`                    |

`@zonsh/ui/illustration` has its own path too, with nothing to add: its editorial images are
files, which every app's build would otherwise carry. Code colours need no setup: Shiki comes
with the package and loads the first time a code block appears.

## Docs and agents

Every component, with live examples and the brand guide: [zon.sh/ui](https://zon.sh/ui). For
agents, the same docs come as [llms.txt](https://zon.sh/ui/llms.txt) and as an MCP server:

```bash
claude mcp add zon-ui -- npx -y @zonsh/ui-mcp
```

Versions: while the library is `0.x`, a minor release may break, always with a migration note in
the changelog, and a patch never does —
[the versioning policy](https://github.com/zonsh/ui/blob/main/docs/versioning.md).

MIT licensed.
