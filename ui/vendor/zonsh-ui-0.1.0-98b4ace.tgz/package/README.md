# @zonsh/ui

The zon component library: React 19 components on Base UI, styled in the zon
material with Tailwind CSS v4. Monochrome, three typefaces, one motion curve.

```bash
pnpm add @zonsh/ui
```

```css
/* app.css — Tailwind first, then the library */
@import "tailwindcss";
@import "@zonsh/ui/styles.css";
```

```tsx
import { Button, Dialog, DialogContent, DialogTrigger } from "@zonsh/ui";
```

```ts
// vite.config.ts — the Licht typeface is proxied through your own origin
import { zonFonts } from "@zonsh/ui/vite";
export default defineConfig({ plugins: [react(), tailwindcss(), zonFonts()] });
```

Requires React 19 and Tailwind CSS 4.1 or later. Dark mode: add `.dark` to `<html>` (see
`ThemeProvider` and `themeScript`).

Documentation, examples and the brand guide: the docs site in the
[repository](https://github.com/73gon/ui), which also ships a Claude skill, an MCP server and
`llms.txt` so agents can build with the library.
